﻿
namespace DiningPhilosophers
{
    public enum State
    {
        Thinking = 0,
        Eating = 1
    }
}