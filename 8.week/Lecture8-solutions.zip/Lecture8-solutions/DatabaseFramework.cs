﻿using System;

namespace Lecture8
{
    public class DatabaseFramework // a class to define functionality of your database like user-functions to add/remove entries from database, etc.
    {
        public static void AddPokemon(Pokemon pokemon) // a function to add pokemon to database
        {
            using (var context = new PokedexContext()) // creating a context object to access database
            {
                context.Pokemons.Add(pokemon);
                context.SaveChanges(); // save changes to database after adding
            }
        }
    }
}
