﻿using Microsoft.EntityFrameworkCore; // required for creating database contexts and model

namespace Lecture8
{
    public class PokedexContext : DbContext // inherits from pre-defined DbContext class in EntityFramework 
    {
        // define database sets to be included in database, here we only require Pokemon list but you can add others as well
        public DbSet<Pokemon> Pokemons { get; set; }

        // select database type to use, using Sqlite here
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // change this with your local machine path
            optionsBuilder.UseSqlite("Data Source=C:/Users/Hritik/Documents/Visual Studio 2022/Projects/ex8/PokedexDatabase.db");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder) // function to define relations among different sets in a database
        {
           /* relations are not required for this example but you can add them if you want, using syntax as follow:
             modelBuilder.Entity<Pokemon> ().HasOne(t => t.type); */
        }
    }
}
