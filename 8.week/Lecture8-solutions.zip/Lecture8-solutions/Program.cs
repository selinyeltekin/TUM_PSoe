﻿using System;
using System.Linq; // required for Linq qweries

namespace Lecture8
{
    class Program
    {
        public static void Main(string[] args)
        {
            string path = "./pokedex.xml";
            var pokedex = HelperFunctions.ReadFromXML(path); // creating a pokedex using input XML file
            
            // searching for certain type of pokemons in pokedex, you can try out other Linq qweries as well
            var electricTypes = from pokemon in pokedex.Pokemons
                                where pokemon.Type.Contains("ELECTRIC")
                                orderby pokemon.Species
                                select pokemon;
            
            foreach(var pokemon in electricTypes)
            {
                Console.WriteLine(pokemon.Species); // printing pokemon names to console (Exercise-1)
                DatabaseFramework.AddPokemon(pokemon); // adding them to database (Exercise-2)
            }

            // pokedex.PrintPokemons(); // check for pokedex
        }
    }
}