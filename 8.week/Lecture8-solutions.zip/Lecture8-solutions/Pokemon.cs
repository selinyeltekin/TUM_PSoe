﻿using System;

namespace Lecture8
{
    public class Pokemon
    {
        public int Id { get; set; } // required for database creation, gets initialise automatically
        public string Species { get; set; } // name of species
        public int DexEntry { get; set; } // pokedex entry number
        public string Type { get; set; } 
        private Pokemon() { } // making default constructor 'private' so that an object without data doesn't get created by mistake
        public Pokemon(string species, int dexEntry, string type)
        {
            this.Species = species;
            this.DexEntry = dexEntry;
            this.Type = type;
        }
    }
}
