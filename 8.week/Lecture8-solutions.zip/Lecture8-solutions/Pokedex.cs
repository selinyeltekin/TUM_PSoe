﻿using System;

namespace Lecture8
{
    class Pokedex
    {
        public List<Pokemon> Pokemons { get; set; } = new List<Pokemon>(); // a pokedex contains a list of pokemons
        public void NewPokemonEntry(Pokemon pokemon)
        {
            this.Pokemons.Add(pokemon);
        }
        public void PrintPokemons() // test function to check whether pokedex is getting created from XML file or not
        {
            foreach(var pokemon in this.Pokemons)
            {
                Console.WriteLine(pokemon.Species);
            }
        }
    }
}
