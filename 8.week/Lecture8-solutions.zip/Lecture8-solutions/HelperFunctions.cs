﻿using System;
using System.Collections.Generic;
using System.Xml;

namespace Lecture8
{
    static class HelperFunctions 
    {
        public static Pokedex ReadFromXML(string path)
        {
            var inputXML = new XmlDocument(); // initialise an XML object
            inputXML.Load(path);

            var pokedex = new Pokedex(); // initialise Pokedex to store Pokemons

            var pokemonNodes = inputXML.DocumentElement.ChildNodes; // get all <pokemon>POKEMON_DATA</pokemon> nodes

            foreach (XmlNode pokemonNode in pokemonNodes) // iterate over each pokemon
            {
                var pokemon = HelperFunctions.GetPokemonInfo(pokemonNode);

                pokedex.NewPokemonEntry(pokemon);
            }

            return pokedex;
        }

        private static Pokemon GetPokemonInfo(XmlNode pokemon)
        {
            // default values incase data isn't present b/w pokemon nodes
            string species = " ", type = " ";
            int dexEntry = 0;

            foreach (XmlNode node in pokemon) // iterate over each child node in pokemon node, e.g. dex, species node
            {
                if (node.Name == "species")
                {
                    species = node.InnerText;
                }
                else if (node.Name == "dex")
                {
                    dexEntry = Convert.ToInt32(node.InnerText);
                }
                else if (node.Name == "types")
                {
                    type = node.InnerText;
                }
                
            }
            return new Pokemon(species, dexEntry, type);
        }
    }
}
