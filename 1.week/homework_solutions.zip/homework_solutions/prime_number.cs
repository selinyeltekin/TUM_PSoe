﻿using System;

namespace Lecture1
{
    class PrimeNumber // a natural number that has only two factors: 1 and itself
    {
        public static void Main()
        {
            int n, i = 2; // can also use uint
            bool flag = true; // number is assumed to be prime by default

            Console.Write("Enter a number: ");
            var input = Console.ReadLine(); // reading string input from Console
            n = Convert.ToInt32(input); // casting/type-conversion to integer 

            while (n < 1) // checks if input number is natural
            {
                Console.WriteLine("It should be a natural number i.e. integer > 0. Try again!");
                Console.Write("Enter a number: ");
                n = Convert.ToInt32(Console.ReadLine());
            }

            while (i <= Math.Sqrt(n))
            {
                if (n % i == 0) // check for factors b/w 2 and sqrt(n)
                {
                    flag = false; // if a factor is found then the number is non-prime  
                    break; // prevents further execution of while loop if a factor is found
                }
                i++;
            }
            // print relevant output to Console
            if (flag && n != 1)  // checks if a factor is found or the number is 1
            {
                Console.WriteLine("Prime");
            }
            else
            {
                Console.WriteLine("Non-Prime");
            }
        }
    } // PrimeNumber
} // Lecture1