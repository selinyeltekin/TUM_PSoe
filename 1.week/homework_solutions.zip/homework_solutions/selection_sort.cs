﻿using System;

namespace Lecture1
{
    class SelectionSort
    {
        public static void Main()
        {
            double[] input = { 4.6, 1.1, 2.0, 5.8, 3.5 };
            int arraySize = input.Length;

            for (int i = 0; i < arraySize - 1; i++) // array indices start at 0 in C#
            {
                int minIndex = i;
                for (int j = i + 1; j < arraySize; j++)
                {
                    if (input[j] < input[minIndex])
                    {
                        minIndex = j; // minimum value if found store its index
                    }
                }
                if (minIndex != i) // swap values if minIndex changes i.e. a minimum value is found to right of current index
                {
                    double temp = input[i]; // required to store initial value at index 'i' temporarily
                    input[i] = input[minIndex];
                    input[minIndex] = temp;
                }
            }
            Console.Write("Sorted Array: \n[");
            foreach (var value in input) // using Enumerator type variable to traverse through array
            {
                Console.Write(value + ",");
            }
            Console.WriteLine("]");
        }
    } // SelectionSort
} // Lecture1