﻿using System;

namespace Lecture1
{
    class GuessTheNumber
    {
        //! steps: 
        //! -> we set the secret number and bounds
        //! -> create a variable to store the user's guess 
        //! -> use a do-while loop: 
        //!     -> get the input as a string 
        //!     -> check if it's a valid integer 
        //!     -> convert it to an integer 
        //!     -> check if it's lower or higher than the "secret number" 
        //!     -> if it's neither then it's equal!

        //* Line 37: Why did we declare the type as "string?" instead of "string"?
        //* What happens if the user enters alphabets or a bunch of spaces instead of a number?

        //TODO Handle the problem described in line 18 (you don't need a try/catch block)
        //TODO Tell the user if their guess is out of the bounds we set in line 27

        public static void Main()
        {
            // controls...
            int secretNumber = 3;
            int[] limitsArray = { 1, 10 }; // used in line 35

            System.Console.WriteLine("Guess The Number!");

            int userGuess = limitsArray[0] - 1; // dummy number just to initialize the variable

            do
            {
                System.Console.WriteLine($"Enter a number between {limitsArray[0]} and {limitsArray[1]}:\t"); // "$" allows us to use variables in a string - similar to print(f"{var}") in python

                string? userGuessStr = Console.ReadLine(); // We take in the user's guess here
                userGuess = Convert.ToInt32(userGuessStr);

                if (userGuess < secretNumber)
                {
                    System.Console.WriteLine("Too low. Try again.\n");
                }
                else if (userGuess > secretNumber)
                {
                    System.Console.WriteLine("Too high. Try again.\n");
                }
                else
                {
                    System.Console.WriteLine("Correct!");
                }
            } while (userGuess != secretNumber);

        }
    } //GuessTheNumber
} //Lecture1