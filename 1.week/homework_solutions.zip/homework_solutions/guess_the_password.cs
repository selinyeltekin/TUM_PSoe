﻿using System;

namespace Lecture1
{
    public class GuessThePassword
    {
        //! steps: 
        //! -> we create a variable to store the user's guess 
        //! -> keep looping and storing the user's guess in the variable we created
        //! -> if the guess matches our password then we print "Correct"

        //* What is the point of "string.IsNullOrEmpty(input)" (line 23)?

        //TODO Try using a do-while loop
        //TODO Try adding an option to exit if the user types "exit" (or "     Exit   ")

        public static void Main()
        {
            string password = "password"; // user needs to guess this

            var input = " "; // user input will be stored in this variable

            while (string.IsNullOrEmpty(input) || password != input) // we keep looping until the user guesses the password correctly
            {
                System.Console.WriteLine("Input your password below: ");

                input = Console.ReadLine(); // we read the user's input here

                if (input != password)
                {
                    System.Console.WriteLine("Incorrect! Try again!");
                }
                else
                {
                    System.Console.WriteLine("Correct!");
                }
            }
        }
    } //GuessThePassword
} //Lecture1