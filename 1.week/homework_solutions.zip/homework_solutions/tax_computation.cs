﻿using System;

namespace Lecture1
{
    public class IncomeTaxCalculator
    {
        //! steps: 
        //! -> we create 3 arrays to store out inputs (percentages/salaries/limits)
        //! -> create an empty array to store our result
        //! -> loop through the salaries: 
        //!     -> check which tax bracket to use (if statement)
        //!     -> calculate the income tax and store it in the empty array
        //! -> loop through the result "incomeTax" and print each array entry to the console

        //TODO Use a foreach loop instead of a for loop to print the income tax

        public static void Main()
        {
            // inputs...
            double[] taxBracketsPercentage = {
                0 , 0.25 , 0.42 , 0.45
            };
            double[] salaryLimits = {
                10e3 , 60e3 , 280e3
            };
            int[] salaries = {
                20432 , 5342 , 88531 , 1032 , 539400
            };

            int numberOfSalaries = salaries.Length;

            double[] incomeTax = new double[numberOfSalaries]; // create a new array that's equal in size to "salaries"

            for (int i = 0; i < numberOfSalaries; i++) // loop through all salaries
            {
                // check salary against all salaryLimits
                if (salaries[i] < salaryLimits[0])
                {
                    incomeTax[i] = 0.0;
                }
                else if (salaries[i] < 60e3 && salaries[i] >= 10e3)
                {
                    incomeTax[i] = (salaries[i] - 10e3) * taxBracketsPercentage[1]; // + 0
                }
                else if (salaries[i] < 280e3 && salaries[i] >= 60e3)
                {
                    incomeTax[i] = (salaries[i] - 60e3) * taxBracketsPercentage[2] + 50e3 * taxBracketsPercentage[1]; // 60e3 - 10e3 = 50e3

                }
                else
                {
                    incomeTax[i] = (salaries[i] - 280e3) * taxBracketsPercentage[3] + 220e3 * taxBracketsPercentage[2] + 50e3 * taxBracketsPercentage[1]; // 280e3 - 60e3 = 220e3
                }
            }

            // print result to console
            for (var i = 0; i < numberOfSalaries; i++)
            {
                System.Console.WriteLine($"Income Tax for employee {i}: \t {incomeTax[i]}");
            }
        }
    } //IncomeTaxCalculator
} //Lecture1