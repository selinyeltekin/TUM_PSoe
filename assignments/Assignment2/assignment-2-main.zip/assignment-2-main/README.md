# Assignment-2

Hello,

Make sure to submit your solution as a zipped folder to moodle.

The zipped folder should be named as "matriculation_number_assignment-2.zip". 

Best, 

ProSE's lecturers and tutors
