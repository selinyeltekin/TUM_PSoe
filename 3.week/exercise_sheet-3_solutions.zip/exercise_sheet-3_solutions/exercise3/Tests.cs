﻿/* Notes: 1. Make sure to keep all test functions inside a class o/w complier would give an error
 * 2. Latest Visual Studio throws a warning for Assert.AreEqual tests
 * since they are classical test models but you can safely ignore those
 * 3. You can also implement them as Assert.That(value1,Is.EqualTo(value2) tests as shown during the lecture
 */

using System;
using NUnit.Framework;

namespace Lecture3
{
    public class ComplexTests
    {
        [Test] // 'Test' Macro to tell complier to recognize following code as a test
        [Category("Constructor")] // name to categorize test
        public void ConstructorTest() // test function
        {
            Complex c = new Complex(1.1, 9.23);
            // GetType() is a pre-defined function that comes with System Objects
            Assert.AreEqual(c.GetType().ToString(), "Lecture3.Complex"); // Object type of a class object/instance should be Namespace.Class
            Assert.AreEqual(c.Imaginary, 9.23);
            Assert.AreEqual(c.Real, 1.1);
        }

        [Test]
        [Category("TryParseComplex")]
        public void TryParseComplexTest()
        {
            Complex c;
            var parseResult = Complex.TryParseComplex("3         +      4 i", out c);
            Assert.True(parseResult); // boolean type test which checks whether parsing is successful or not 
            Assert.AreEqual(c.Imaginary, 4.0);
            Assert.AreEqual(c.Real, 3.0);
        }

        [Test]
        [Category("CreateComplexValue")]
        public void CreateComplexTest()
        {
            Complex c = Complex.CreateComplexValue(6, 7.5);
            Assert.AreEqual(c.Imaginary, 7.5);
            Assert.AreEqual(c.Real, 6.0);
        }

        [Test]
        [Category("Norm")]
        public void NormTest()
        {
            Complex c = new Complex(5,12);
            var norm = c.GetNorm();
            Assert.AreEqual(norm, 13.0);
        }
    }
}
