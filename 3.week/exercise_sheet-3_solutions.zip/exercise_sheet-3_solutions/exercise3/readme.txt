Make sure to keep 'Complex' and 'Tests' files inside the respective projects as shown during the lecture.

For additional test assertions you can checkout the following link:
https://docs.nunit.org/articles/nunit/writing-tests/assertions/assertion-models/classic.html